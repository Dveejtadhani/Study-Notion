import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token if available
api.interceptors.request.use(
  (config) => {
    const user = localStorage.getItem('user');
    if (user) {
      const userData = JSON.parse(user);
      config.headers.Authorization = `Bearer ${userData._id}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API calls
export const authAPI = {
  signup: (userData) => api.post('/auth/signup', userData),
  login: (credentials) => api.post('/auth/login', credentials),
  getUserProfile: (userId) => api.get(`/auth/profile/${userId}`),
};

// Course API calls
export const courseAPI = {
  getAllCourses: (params) => api.get('/courses', { params }),
  getCourse: (courseId) => api.get(`/courses/${courseId}`),
  createCourse: (courseData) => api.post('/courses', courseData),
  updateCourse: (courseId, courseData) => api.put(`/courses/${courseId}`, courseData),
  deleteCourse: (courseId, instructorId) => api.delete(`/courses/${courseId}`, { data: { instructorId } }),
  getCoursesByInstructor: (instructorId) => api.get(`/courses/instructor/${instructorId}`),
  enrollInCourse: (courseId, userId) => api.post(`/courses/${courseId}/enroll`, { userId }),
  checkEnrollment: (courseId, userId) => api.get(`/courses/${courseId}/enrollment/${userId}`),
  getEnrolledCourses: (userId) => api.get(`/courses/user/${userId}/enrolled-courses`),
  rateCourse: (courseId, ratingData) => api.post(`/courses/${courseId}/rate`, ratingData),
  getCourseRatings: (courseId) => api.get(`/courses/${courseId}/ratings`),
};

// Payment API calls (simulated for now)
export const paymentAPI = {
  processPayment: (paymentData) => {
    // This is a simulated payment processing function
    // In a real application, this would make an API call to a payment processor
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          data: {
            success: true,
            transactionId: 'txn_' + Math.random().toString(36).substr(2, 9),
            message: 'Payment processed successfully'
          }
        });
      }, 2000);
    });
  },
  getPaymentHistory: (userId) => {
    // This would fetch payment history from the backend
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          data: {
            payments: []
          }
        });
      }, 1000);
    });
  }
};



export default api;
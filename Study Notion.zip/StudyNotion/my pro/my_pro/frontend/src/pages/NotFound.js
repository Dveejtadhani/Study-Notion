import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Search } from 'lucide-react';

const NotFound = () => {
  return (
    <div className="min-h-screen bg-secondary-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full text-center">
        <div className="text-8xl mb-6">😕</div>
        
        <h1 className="text-6xl font-bold text-secondary-900 mb-4">
          404
        </h1>
        
        <h2 className="text-2xl font-semibold text-secondary-900 mb-4">
          Page Not Found
        </h2>
        
        <p className="text-secondary-600 mb-8 text-lg">
          Oops! The page you're looking for doesn't exist. It might have been moved, deleted, or you entered the wrong URL.
        </p>
        
        <div className="space-y-4">
          <Link
            to="/"
            className="btn-primary inline-flex items-center space-x-2 w-full justify-center"
          >
            <Home className="h-5 w-5" />
            <span>Go to Homepage</span>
          </Link>
          
          <Link
            to="/courses"
            className="btn-outline inline-flex items-center space-x-2 w-full justify-center"
          >
            <Search className="h-5 w-5" />
            <span>Browse Courses</span>
          </Link>
        </div>
        
        <div className="mt-8 pt-8 border-t border-secondary-200">
          <p className="text-sm text-secondary-500">
            If you believe this is an error, please contact our support team.
          </p>
        </div>
      </div>
    </div>
  );
};

export default NotFound; 
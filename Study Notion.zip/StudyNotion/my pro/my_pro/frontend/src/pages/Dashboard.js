import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { courseAPI } from '../services/api';
import { toast } from 'react-toastify';
import { Plus, Edit, Trash2, BookOpen, Users } from 'lucide-react';
import DashboardCourseCard from '../components/DashboardCourseCard';

const Dashboard = () => {
  const { user } = useAuth();
  const [myCourses, setMyCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateForm, setShowCreateForm] = useState(false);

  const [editingCourse, setEditingCourse] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Programming',
    thumbnail: '',
    videoUrl: '',
    price: '',
    duration: '',
    level: 'Beginner',
    tags: ''
  });

  const categories = [
    'Programming',
    'Design',
    'Business',
    'Marketing',
    'Music',
    'Photography',
    'Data Science',
    'Backend Development',
    'Frontend Development',
    'Mobile Development',
    'DevOps',
    'Other'
  ];

  const levels = ['Beginner', 'Intermediate', 'Advanced'];

  const fetchMyCourses = useCallback(async () => {
    try {
      if (user?.role === 'instructor') {
        // Fetch courses created by the instructor
        const response = await courseAPI.getCoursesByInstructor(user._id);
        setMyCourses(response.data.courses);
      } else {
        // Fetch courses enrolled by the student
        const response = await courseAPI.getEnrolledCourses(user._id);
        setMyCourses(response.data.courses);
      }
    } catch (error) {
      console.error('Error fetching courses:', error);
      toast.error('Failed to load your courses');
    } finally {
      setLoading(false);
    }
  }, [user._id, user?.role]);

  useEffect(() => {
    fetchMyCourses();
  }, [fetchMyCourses]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    console.log('Current user:', user);
    console.log('Form data:', formData);
    
    if (!user || !user._id) {
      toast.error('User not authenticated');
      return;
    }
    
    const courseData = {
      ...formData,
      price: parseFloat(formData.price) || 0,
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      instructorId: user._id
    };

    console.log('Submitting course data:', courseData);

    try {
      if (editingCourse) {
        console.log('Updating course:', editingCourse._id);
        await courseAPI.updateCourse(editingCourse._id, courseData);
        toast.success('Course updated successfully!');
      } else {
        console.log('Creating new course');
        const response = await courseAPI.createCourse(courseData);
        console.log('Create course response:', response);
        toast.success('Course created successfully!');
      }
      
      resetForm();
      fetchMyCourses();
    } catch (error) {
      console.error('Error saving course:', error);
      console.error('Error response:', error.response?.data);
      toast.error(error.response?.data?.message || 'Failed to save course');
    }
  };

  const handleEdit = (course) => {
    setEditingCourse(course);
    setFormData({
      title: course.title,
      description: course.description,
      category: course.category,
      thumbnail: course.thumbnail,
      videoUrl: course.videoUrl,
      price: course.price.toString(),
      duration: course.duration,
      level: course.level,
      tags: course.tags ? course.tags.join(', ') : ''
    });
    setShowCreateForm(true);
  };

  const handleDelete = async (courseId) => {
    if (window.confirm('Are you sure you want to delete this course?')) {
      try {
        await courseAPI.deleteCourse(courseId, user._id);
        toast.success('Course deleted successfully!');
        fetchMyCourses();
      } catch (error) {
        console.error('Error deleting course:', error);
        toast.error('Failed to delete course');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      category: 'Programming',
      thumbnail: '',
      videoUrl: '',
      price: '',
      duration: '',
      level: 'Beginner',
      tags: ''
    });
    setEditingCourse(null);
    setShowCreateForm(false);
  };

  const fillSampleData = () => {
    setFormData({
      title: 'Sample Course Title',
      description: 'This is a sample course description that meets the minimum length requirement for testing purposes.',
      category: 'Programming',
      thumbnail: 'https://example.com/sample-thumbnail.jpg',
      videoUrl: 'https://www.youtube.com/watch?v=sample',
      price: '29.99',
      duration: '5 hours',
      level: 'Beginner',
      tags: 'JavaScript, React, Web Development'
    });
  };

  const stats = [
    { icon: BookOpen, label: 'Total Courses', value: myCourses.length },
    { icon: Users, label: 'Total Students', value: myCourses.reduce((sum, course) => sum + course.enrolledStudents, 0) },
    { 
      icon: BookOpen, 
      label: 'Average Rating', 
      value: myCourses.length > 0 
        ? (myCourses.reduce((sum, course) => sum + (course.rating || 0), 0) / myCourses.length).toFixed(1) + '/5'
                  : '0.0/5' 
    }
  ];

  return (
    <div className="min-h-screen bg-secondary-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-secondary-900 mb-2">
            Welcome back, {user?.name}!
          </h1>
          <p className="text-secondary-600">
            {user?.role === 'instructor' 
              ? 'Manage your courses and track your students'
              : 'Track your enrolled courses'
            }
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {user?.role === 'instructor' ? (
            // Instructor stats
            stats.map((stat, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center">
                  <div className="p-2 bg-primary-100 rounded-lg">
                    <stat.icon className="h-6 w-6 text-primary-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-secondary-600">{stat.label}</p>
                    <p className="text-2xl font-bold text-secondary-900">{stat.value}</p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            // Student stats
            [
              { icon: BookOpen, label: 'Enrolled Courses', value: myCourses.length }
            ].map((stat, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center">
                  <div className="p-2 bg-primary-100 rounded-lg">
                    <stat.icon className="h-6 w-6 text-primary-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-secondary-600">{stat.label}</p>
                    <p className="text-2xl font-bold text-secondary-900">{stat.value}</p>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Course Section Header */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-secondary-900">
            {user?.role === 'instructor' ? 'My Courses' : 'Enrolled Courses'}
          </h2>
          {user?.role === 'instructor' && (
            <button
              onClick={() => setShowCreateForm(true)}
              className="btn-primary flex items-center space-x-2"
            >
              <Plus className="h-5 w-5" />
              <span>Create Course</span>
            </button>
          )}
        </div>

        {/* Create/Edit Course Form - Only for Instructors */}
        {showCreateForm && user?.role === 'instructor' && (
          <div className="bg-white rounded-xl p-6 shadow-lg mb-8">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-semibold text-secondary-900">
                {editingCourse ? 'Edit Course' : 'Create New Course'}
              </h3>
              <button
                onClick={resetForm}
                className="text-secondary-600 hover:text-secondary-800"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Course Title *
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    required
                    className="input-field"
                    placeholder="Enter course title"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Category *
                  </label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    className="input-field"
                  >
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Price ($)
                  </label>
                  <input
                    type="number"
                    name="price"
                    value={formData.price}
                    onChange={handleInputChange}
                    min="0"
                    step="0.01"
                    className="input-field"
                    placeholder="0.00"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Duration
                  </label>
                  <input
                    type="text"
                    name="duration"
                    value={formData.duration}
                    onChange={handleInputChange}
                    className="input-field"
                    placeholder="e.g., 5 hours"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Level
                  </label>
                  <select
                    name="level"
                    value={formData.level}
                    onChange={handleInputChange}
                    className="input-field"
                  >
                    {levels.map((level) => (
                      <option key={level} value={level}>
                        {level}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-secondary-700 mb-2">
                    Tags (comma-separated)
                  </label>
                  <input
                    type="text"
                    name="tags"
                    value={formData.tags}
                    onChange={handleInputChange}
                    className="input-field"
                    placeholder="e.g., JavaScript, React, Web Development"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-secondary-700 mb-2">
                  Thumbnail URL *
                </label>
                <input
                  type="url"
                  name="thumbnail"
                  value={formData.thumbnail}
                  onChange={handleInputChange}
                  required
                  className="input-field"
                  placeholder="https://example.com/image.jpg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-secondary-700 mb-2">
                  Video URL *
                </label>
                <input
                  type="url"
                  name="videoUrl"
                  value={formData.videoUrl}
                  onChange={handleInputChange}
                  required
                  className="input-field"
                  placeholder="https://www.youtube.com/watch?v=..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-secondary-700 mb-2">
                  Description *
                </label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  required
                  rows="4"
                  className="input-field"
                  placeholder="Enter course description..."
                />
              </div>

              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={fillSampleData}
                  className="btn-secondary"
                >
                  Fill Sample Data
                </button>
                <div className="flex space-x-4">
                  <button
                    type="button"
                    onClick={resetForm}
                    className="btn-secondary"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="btn-primary"
                  >
                    {editingCourse ? 'Update Course' : 'Create Course'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        )}

        {/* My Courses List */}
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
          </div>
        ) : myCourses.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl shadow-lg">
            <div className="text-6xl mb-4">
              {user?.role === 'instructor' ? '📚' : '🎓'}
            </div>
            <h3 className="text-xl font-semibold text-secondary-900 mb-2">
              {user?.role === 'instructor' ? 'No courses yet' : 'No enrolled courses yet'}
            </h3>
            <p className="text-secondary-600 mb-4">
              {user?.role === 'instructor' 
                ? 'Start creating your first course to share your knowledge'
                : 'Browse and enroll in courses to start your learning journey'
              }
            </p>
            {user?.role === 'instructor' ? (
              <button
                onClick={() => setShowCreateForm(true)}
                className="btn-primary"
              >
                Create Your First Course
              </button>
            ) : (
              <Link
                to="/courses"
                className="btn-primary"
              >
                Browse Courses
              </Link>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myCourses.map((course) => (
              <div key={course._id} className="relative group">
                <DashboardCourseCard course={course} />
                {user?.role === 'instructor' && (
                  <>
                    {/* Subtle background overlay for buttons */}
                    <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-white/80 to-transparent rounded-bl-full pointer-events-none"></div>
                    <div className="absolute top-4 right-4 flex space-x-2 z-10">
                      <button
                        onClick={() => handleEdit(course)}
                        className="p-3 bg-white rounded-full shadow-lg hover:bg-primary-50 transition-all duration-200 hover:scale-110 border border-gray-200 hover:shadow-xl"
                        title="Edit Course"
                      >
                        <Edit className="h-5 w-5 text-primary-600" />
                      </button>
                      <button
                        onClick={() => handleDelete(course._id)}
                        className="p-3 bg-white rounded-full shadow-lg hover:bg-red-50 transition-all duration-200 hover:scale-110 border border-gray-200 hover:shadow-xl"
                        title="Delete Course"
                      >
                        <Trash2 className="h-5 w-5 text-red-600" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard; 
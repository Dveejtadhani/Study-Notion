import React from 'react';
import { Link } from 'react-router-dom';
import { GraduationCap, BookOpen, Users, Star, Play, Award } from 'lucide-react';

const AuthSelection = () => {
  return (
    <div className="min-h-screen bg-secondary-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-secondary-900 mb-4">
            Welcome to StudyNotion
          </h1>
          <p className="text-lg text-secondary-600 max-w-2xl mx-auto">
            Choose your role to get started with your learning journey
          </p>
        </div>

        {/* Role Selection Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Student Card */}
          <div className="bg-white rounded-xl shadow-lg p-8 border-2 border-transparent hover:border-primary-200 transition-all duration-300">
            <div className="text-center mb-6">
              <div className="mx-auto h-16 w-16 bg-primary-100 rounded-full flex items-center justify-center mb-4">
                <GraduationCap className="h-8 w-8 text-primary-600" />
              </div>
              <h2 className="text-2xl font-bold text-secondary-900 mb-2">
                I'm a Student
              </h2>
              <p className="text-secondary-600">
                Learn from expert instructors and advance your skills
              </p>
            </div>

            {/* Student Features */}
            <div className="space-y-3 mb-8">
              <div className="flex items-center space-x-3">
                <Play className="h-5 w-5 text-primary-600" />
                <span className="text-secondary-700">Access to thousands of courses</span>
              </div>
              <div className="flex items-center space-x-3">
                <Star className="h-5 w-5 text-primary-600" />
                <span className="text-secondary-700">Rate and review courses</span>
              </div>
              <div className="flex items-center space-x-3">
                <Users className="h-5 w-5 text-primary-600" />
                <span className="text-secondary-700">Learn at your own pace</span>
              </div>
              <div className="flex items-center space-x-3">
                <Award className="h-5 w-5 text-primary-600" />
                <span className="text-secondary-700">Earn certificates</span>
              </div>
            </div>

            {/* Student Action Buttons */}
            <div className="space-y-3">
              <Link
                to="/student/signup"
                className="w-full btn-primary flex items-center justify-center space-x-2"
              >
                <GraduationCap className="h-5 w-5" />
                <span>Sign Up as Student</span>
              </Link>
              <Link
                to="/student/login"
                className="w-full btn-secondary flex items-center justify-center"
              >
                Sign In as Student
              </Link>
            </div>
          </div>

          {/* Instructor Card */}
          <div className="bg-white rounded-xl shadow-lg p-8 border-2 border-transparent hover:border-secondary-200 transition-all duration-300">
            <div className="text-center mb-6">
              <div className="mx-auto h-16 w-16 bg-secondary-100 rounded-full flex items-center justify-center mb-4">
                <BookOpen className="h-8 w-8 text-secondary-600" />
              </div>
              <h2 className="text-2xl font-bold text-secondary-900 mb-2">
                I'm an Instructor
              </h2>
              <p className="text-secondary-600">
                Share your knowledge and create amazing courses
              </p>
            </div>

            {/* Instructor Features */}
            <div className="space-y-3 mb-8">
              <div className="flex items-center space-x-3">
                <BookOpen className="h-5 w-5 text-secondary-600" />
                <span className="text-secondary-700">Create and publish courses</span>
              </div>
              <div className="flex items-center space-x-3">
                <Users className="h-5 w-5 text-secondary-600" />
                <span className="text-secondary-700">Reach thousands of students</span>
              </div>
              <div className="flex items-center space-x-3">
                <Star className="h-5 w-5 text-secondary-600" />
                <span className="text-secondary-700">Earn from your expertise</span>
              </div>
              <div className="flex items-center space-x-3">
                <Award className="h-5 w-5 text-secondary-600" />
                <span className="text-secondary-700">Build your teaching brand</span>
              </div>
            </div>

            {/* Instructor Action Buttons */}
            <div className="space-y-3">
              <Link
                to="/instructor/signup"
                className="w-full bg-secondary-600 hover:bg-secondary-700 text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2"
              >
                <BookOpen className="h-5 w-5" />
                <span>Sign Up as Instructor</span>
              </Link>
              <Link
                to="/instructor/login"
                className="w-full btn-secondary flex items-center justify-center"
              >
                Sign In as Instructor
              </Link>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center">
          <p className="text-secondary-600 mb-4">
            Already have an account? Choose your role above to sign in
          </p>
          <Link
            to="/"
            className="text-primary-600 hover:text-primary-500 font-medium"
          >
            ← Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default AuthSelection; 
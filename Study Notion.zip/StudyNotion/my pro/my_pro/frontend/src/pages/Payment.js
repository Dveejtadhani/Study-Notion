import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { courseAPI, paymentAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import { ArrowLeft, CreditCard, CheckCircle } from 'lucide-react';

const Payment = () => {
  const location = useLocation();
  const { courseId } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('credit_card');
  const [formData, setFormData] = useState({
    cardNumber: '',
    cardName: '',
    expiryDate: '',
    cvv: ''
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    // Redirect if not authenticated
    if (!isAuthenticated) {
      toast.error('Please login to continue');
      navigate('/auth');
      return;
    }

    // Get course ID from location state or params
    const id = location.state?.courseId || courseId;
    if (!id) {
      toast.error('Course information missing');
      navigate('/courses');
      return;
    }

    const fetchCourse = async () => {
      try {
        const response = await courseAPI.getCourse(id);
        setCourse(response.data.course);
      } catch (error) {
        console.error('Error fetching course:', error);
        toast.error('Failed to load course information');
        navigate('/courses');
      } finally {
        setLoading(false);
      }
    };

    fetchCourse();
  }, [courseId, location.state, isAuthenticated, navigate]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });

    // Clear error when user types
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    // Basic validation
    if (!formData.cardNumber.trim()) {
      newErrors.cardNumber = 'Card number is required';
    } else if (!/^\d{16}$/.test(formData.cardNumber.replace(/\s/g, ''))) {
      newErrors.cardNumber = 'Invalid card number';
    }

    if (!formData.cardName.trim()) {
      newErrors.cardName = 'Cardholder name is required';
    }

    if (!formData.expiryDate.trim()) {
      newErrors.expiryDate = 'Expiry date is required';
    } else if (!/^(0[1-9]|1[0-2])\/\d{2}$/.test(formData.expiryDate)) {
      newErrors.expiryDate = 'Invalid format (MM/YY)';
    }

    if (!formData.cvv.trim()) {
      newErrors.cvv = 'CVV is required';
    } else if (!/^\d{3,4}$/.test(formData.cvv)) {
      newErrors.cvv = 'Invalid CVV';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setProcessing(true);

    try {
      // Process payment using the payment API
      await paymentAPI.processPayment({
        courseId: course._id,
        userId: user._id,
        amount: course.price,
        paymentMethod: paymentMethod,
        cardDetails: {
          number: formData.cardNumber.replace(/\s/g, ''),
          name: formData.cardName,
          expiry: formData.expiryDate,
          cvv: formData.cvv
        }
      });
      
      // After successful payment, enroll in the course
      await courseAPI.enrollInCourse(course._id, user._id);
      setPaymentSuccess(true);
      toast.success('Payment successful! You are now enrolled in the course.');
      
      // Redirect to course learning page after a delay
      setTimeout(() => {
        navigate(`/course/${course._id}/learn`);
      }, 2000);
    } catch (error) {
      console.error('Error processing payment:', error);
      toast.error('Payment failed. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
        </div>
      </div>
    );
  }

  if (paymentSuccess) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="bg-white rounded-xl p-8 shadow-lg text-center">
          <div className="mx-auto h-16 w-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-secondary-900 mb-2">Payment Successful!</h2>
          <p className="text-secondary-600 mb-6">You are now enrolled in {course.title}</p>
          <button
            onClick={() => navigate(`/course/${course._id}/learn`)}
            className="btn-primary"
          >
            Start Learning
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <button
        onClick={() => navigate(`/courses/${course._id}`)}
        className="flex items-center text-primary-600 hover:text-primary-700 mb-6"
      >
        <ArrowLeft className="h-4 w-4 mr-1" />
        Back to Course
      </button>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Payment Form */}
        <div className="md:col-span-2">
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h2 className="text-2xl font-bold text-secondary-900 mb-6">Payment Details</h2>
            
            <div className="mb-6">
              <div className="flex space-x-4 mb-4">
                <button
                  type="button"
                  className={`flex-1 py-3 px-4 rounded-lg border ${paymentMethod === 'credit_card' ? 'border-primary-600 bg-primary-50' : 'border-secondary-300'} flex items-center justify-center`}
                  onClick={() => setPaymentMethod('credit_card')}
                >
                  <CreditCard className="h-5 w-5 mr-2" />
                  <span>Credit Card</span>
                </button>
                <button
                  type="button"
                  className={`flex-1 py-3 px-4 rounded-lg border ${paymentMethod === 'paypal' ? 'border-primary-600 bg-primary-50' : 'border-secondary-300'} flex items-center justify-center`}
                  onClick={() => setPaymentMethod('paypal')}
                >
                  <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944 3.384a.77.77 0 0 1 .757-.645h6.737c2.785 0 4.765 1.885 4.765 4.546 0 .28-.022.57-.07.874-.534 3.211-2.838 4.389-5.616 4.389H9.012c-.298 0-.557.192-.633.48l-1.303 8.309zm10.507-8.326c-.106.338-.245.654-.424.942 1.08.115 1.936.451 1.936 1.902 0 1.417-1.246 2.175-3.582 2.175h-.424l.07-.45c.035-.226.228-.396.457-.396h.053c.793 0 1.45-.202 1.45-.767 0-.36-.352-.536-1.002-.536h-.34a.694.694 0 0 0-.687.581l-.598 3.809a.77.77 0 0 1-.757.645H11.18a.641.641 0 0 1-.633-.74l.316-2.015.316-2.015.633-4.029c.035-.226.228-.396.457-.396h.053c.793 0 1.45-.202 1.45-.767 0-.36-.352-.536-1.002-.536h-.34a.694.694 0 0 0-.687.581l-.598 3.809a.77.77 0 0 1-.757.645H7.732a.641.641 0 0 1-.633-.74l1.897-12.09a.77.77 0 0 1 .757-.645h6.737c2.785 0 4.765 1.885 4.765 4.546 0 2.538-1.633 4.389-3.67 4.389z" />
                  </svg>
                  <span>PayPal</span>
                </button>
              </div>
            </div>

            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label htmlFor="cardNumber" className="block text-sm font-medium text-secondary-700 mb-1">
                    Card Number
                  </label>
                  <input
                    id="cardNumber"
                    name="cardNumber"
                    type="text"
                    placeholder="1234 5678 9012 3456"
                    className={`input-field ${errors.cardNumber ? 'border-red-500 focus:ring-red-500' : ''}`}
                    value={formData.cardNumber}
                    onChange={handleInputChange}
                    maxLength="19"
                  />
                  {errors.cardNumber && (
                    <p className="mt-1 text-sm text-red-600">{errors.cardNumber}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="cardName" className="block text-sm font-medium text-secondary-700 mb-1">
                    Cardholder Name
                  </label>
                  <input
                    id="cardName"
                    name="cardName"
                    type="text"
                    placeholder="John Doe"
                    className={`input-field ${errors.cardName ? 'border-red-500 focus:ring-red-500' : ''}`}
                    value={formData.cardName}
                    onChange={handleInputChange}
                  />
                  {errors.cardName && (
                    <p className="mt-1 text-sm text-red-600">{errors.cardName}</p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="expiryDate" className="block text-sm font-medium text-secondary-700 mb-1">
                      Expiry Date
                    </label>
                    <input
                      id="expiryDate"
                      name="expiryDate"
                      type="text"
                      placeholder="MM/YY"
                      className={`input-field ${errors.expiryDate ? 'border-red-500 focus:ring-red-500' : ''}`}
                      value={formData.expiryDate}
                      onChange={handleInputChange}
                      maxLength="5"
                    />
                    {errors.expiryDate && (
                      <p className="mt-1 text-sm text-red-600">{errors.expiryDate}</p>
                    )}
                  </div>

                  <div>
                    <label htmlFor="cvv" className="block text-sm font-medium text-secondary-700 mb-1">
                      CVV
                    </label>
                    <input
                      id="cvv"
                      name="cvv"
                      type="text"
                      placeholder="123"
                      className={`input-field ${errors.cvv ? 'border-red-500 focus:ring-red-500' : ''}`}
                      value={formData.cvv}
                      onChange={handleInputChange}
                      maxLength="4"
                    />
                    {errors.cvv && (
                      <p className="mt-1 text-sm text-red-600">{errors.cvv}</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <button
                  type="submit"
                  disabled={processing}
                  className="w-full btn-primary py-3 flex items-center justify-center"
                >
                  {processing ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      Processing Payment...
                    </>
                  ) : (
                    <>Pay ₹{course.price.toFixed(2)}</>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Order Summary */}
        <div className="md:col-span-1">
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <h3 className="text-xl font-semibold text-secondary-900 mb-4">Order Summary</h3>
            
            <div className="mb-4">
              <div className="aspect-video rounded-lg overflow-hidden mb-4">
                <img 
                  src={course.thumbnail} 
                  alt={course.title} 
                  className="w-full h-full object-cover"
                />
              </div>
              <h4 className="font-medium text-secondary-900">{course.title}</h4>
              <p className="text-sm text-secondary-600">{course.instructor?.name}</p>
            </div>
            
            <div className="border-t border-secondary-200 pt-4">
              <div className="flex justify-between mb-2">
                <span className="text-secondary-600">Course Price</span>
                <span className="font-medium">₹{course.price.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between font-bold text-lg mt-4 pt-4 border-t border-secondary-200">
                <span>Total</span>
                <span className="text-primary-600">₹{course.price.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payment;
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { courseAPI } from '../services/api';
import { ArrowLeft, CheckCircle, Clock, Users } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import Rating from '../components/Rating';


const CourseLearning = () => {
  const { id } = useParams();
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const videoRef = useRef(null);

  const fetchCourse = useCallback(async () => {
    try {
      const response = await courseAPI.getCourse(id);
      setCourse(response.data.course);
      
      // Check if user is enrolled
      if (!isAuthenticated) {
        setError('You must be logged in to access course content');
        return;
      }
      
      if (isAuthenticated && user && user._id) {
        const enrollmentResponse = await courseAPI.checkEnrollment(id, user._id);
        if (!enrollmentResponse.data.isEnrolled) {
          setError('You must enroll in this course to access the learning content');
          return;
        }
      } else if (isAuthenticated && (!user || !user._id)) {
        setError('User information not available. Please try logging in again.');
        return;
      }
    } catch (error) {
      console.error('Error fetching course:', error);
      setError('Course not found or error loading course');
    } finally {
      setLoading(false);
    }
  }, [id, isAuthenticated, user]);





  useEffect(() => {
    fetchCourse();
  }, [fetchCourse]);

  const getVideoEmbedUrl = (videoUrl) => {
    // Handle YouTube URLs
    if (videoUrl.includes('youtube.com/watch?v=')) {
      const videoId = videoUrl.split('v=')[1];
      return `https://www.youtube.com/embed/${videoId}`;
    }
    // Handle YouTube short URLs
    if (videoUrl.includes('youtu.be/')) {
      const videoId = videoUrl.split('youtu.be/')[1];
      return `https://www.youtube.com/embed/${videoId}`;
    }
    // Return original URL if not YouTube
    return videoUrl;
  };



  if (loading || authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (error || !course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">😕</div>
          <h2 className="text-2xl font-bold text-secondary-900 mb-2">
            {error || 'Course not found'}
          </h2>
          <p className="text-secondary-600 mb-4">
            The course you're looking for doesn't exist or has been removed.
          </p>
          <Link
            to="/courses"
            className="btn-primary inline-flex items-center space-x-2"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Courses</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-secondary-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-6">
          <Link
            to="/courses"
            className="inline-flex items-center space-x-2 text-primary-600 hover:text-primary-700 transition-colors duration-200"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Courses</span>
          </Link>
        </div>

        {/* Success Message */}
        <div className="bg-green-50 border border-green-200 rounded-xl p-6 mb-8">
          <div className="flex items-center space-x-3">
            <CheckCircle className="h-8 w-8 text-green-600" />
            <div>
              <h2 className="text-xl font-semibold text-green-800">
                Welcome to {course.title}!
              </h2>
              <p className="text-green-700">
                You have successfully enrolled in this course. Start learning now!
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Video Player */}
            <div className="bg-black rounded-xl overflow-hidden mb-8">
              <div className="aspect-video">
                {(() => {
                  // Check if it's a YouTube URL
                  const isYouTube = course.videoUrl.includes('youtube.com') || course.videoUrl.includes('youtu.be');
                  
                  if (isYouTube) {
                    return (
                      <iframe
                        src={getVideoEmbedUrl(course.videoUrl)}
                        title={course.title}
                        className="w-full h-full"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      ></iframe>
                    );
                  } else {
                    return (
                      <video
                        ref={videoRef}
                        className="w-full h-full"
                        controls
                      >
                        <source src={course.videoUrl} type="video/mp4" />
                        Your browser does not support the video tag.
                      </video>
                    );
                  }
                })()}
              </div>
            </div>

            {/* Course Content */}
            <div className="bg-white rounded-xl p-6 mb-6">
              <h1 className="text-3xl font-bold text-secondary-900 mb-4">
                {course.title}
              </h1>
              
              <div className="flex flex-wrap items-center gap-4 mb-6">
                <div className="flex items-center space-x-1">
                  <Rating rating={course.rating} readonly={true} size="sm" />
                </div>
                
                <div className="flex items-center space-x-1 text-secondary-600">
                  <Users className="h-4 w-4" />
                  <span className="text-sm">{course.enrolledStudents} students enrolled</span>
                </div>
                
                <div className="flex items-center space-x-1 text-secondary-600">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm">{course.duration}</span>
                </div>
              </div>

              <div className="prose max-w-none text-secondary-700">
                <p className="whitespace-pre-wrap">{course.description}</p>
              </div>
            </div>


          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl p-6 shadow-lg sticky top-24">
              <div className="text-center mb-6">
                <div className="text-3xl font-bold text-primary-600 mb-2">
                  {course.price === 0 ? 'Free' : `$${course.price}`}
                </div>
                <div className="bg-green-100 text-green-800 px-4 py-2 rounded-lg">
                  <div className="flex items-center justify-center space-x-2">
                    <CheckCircle className="h-5 w-5" />
                    <span className="font-medium">Enrolled</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between py-2 border-b border-secondary-200">
                  <span className="text-secondary-600">Duration</span>
                  <span className="font-medium">{course.duration}</span>
                </div>
                
                <div className="flex items-center justify-between py-2 border-b border-secondary-200">
                  <span className="text-secondary-600">Level</span>
                  <span className="font-medium">{course.level}</span>
                </div>
                
                <div className="flex items-center justify-between py-2 border-b border-secondary-200">
                  <span className="text-secondary-600">Category</span>
                  <span className="font-medium">{course.category}</span>
                </div>
                
                <div className="flex items-center justify-between py-2 border-b border-secondary-200">
                  <span className="text-secondary-600">Students</span>
                  <span className="font-medium">{course.enrolledStudents}</span>
                </div>
                
                <div className="flex items-center justify-between py-2">
                  <span className="text-secondary-600">Rating</span>
                  <Rating rating={course.rating} readonly={true} size="sm" showValue={false} />
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-secondary-200">
                <h3 className="font-semibold text-secondary-900 mb-3">
                  What you'll learn
                </h3>
                <ul className="space-y-2 text-sm text-secondary-700">
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-primary-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Comprehensive understanding of the subject</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-primary-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Practical skills and real-world applications</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-primary-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Certificate upon completion</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseLearning; 
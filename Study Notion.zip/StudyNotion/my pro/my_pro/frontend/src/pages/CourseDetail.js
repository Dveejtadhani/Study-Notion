import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { courseAPI } from '../services/api';
import { Clock, Users, Play, ArrowLeft, Tag, CheckCircle, MessageSquare } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import Rating from '../components/Rating';
import VideoModal from '../components/VideoModal';

const CourseDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isAuthenticated, loading: authLoading } = useAuth();
  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [enrolling, setEnrolling] = useState(false);
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [userRating, setUserRating] = useState(0);
  const [userReview, setUserReview] = useState('');
  const [showRatingForm, setShowRatingForm] = useState(false);
  const [submittingRating, setSubmittingRating] = useState(false);
  const [courseRatings, setCourseRatings] = useState([]);
  const [showVideoModal, setShowVideoModal] = useState(false);

  const checkEnrollmentStatus = useCallback(async () => {
    if (!user || !user._id) return;
    
    try {
      const response = await courseAPI.checkEnrollment(id, user._id);
      setIsEnrolled(response.data.isEnrolled);
    } catch (error) {
      console.error('Error checking enrollment:', error);
      setIsEnrolled(false);
    }
  }, [id, user]);

  const fetchCourse = useCallback(async () => {
    try {
      const response = await courseAPI.getCourse(id);
      setCourse(response.data.course);
      
      // Check if user is enrolled (if authenticated and not loading)
      if (isAuthenticated && user && user._id && !authLoading) {
        checkEnrollmentStatus();
      }
    } catch (error) {
      console.error('Error fetching course:', error);
      setError('Course not found or error loading course');
    } finally {
      setLoading(false);
    }
  }, [id, isAuthenticated, user, authLoading, checkEnrollmentStatus]);

  const fetchCourseRatings = useCallback(async () => {
    try {
      const response = await courseAPI.getCourseRatings(id);
      setCourseRatings(response.data.ratings);
      
      // Check if user has already rated
      if (user && user._id) {
        const userRatingData = response.data.ratings.find(
          r => r.user._id === user._id
        );
        if (userRatingData) {
          setUserRating(userRatingData.rating);
          setUserReview(userRatingData.review || '');
        }
      }
    } catch (error) {
      console.error('Error fetching ratings:', error);
    }
  }, [id, user]);

  const handleEnroll = async () => {
    if (!isAuthenticated) {
      toast.info('Please login to enroll in this course');
      navigate('/auth');
      return;
    }

    if (!user || !user._id) {
      toast.error('User information not available. Please try logging in again.');
      navigate('/auth');
      return;
    }

    // Check if user is an instructor
    if (user.role === 'instructor') {
      toast.error('Instructors cannot enroll in courses. You can only create and manage your own courses.');
      return;
    }

    // Check if user is trying to enroll in their own course (if they're an instructor)
    if (course.instructor && course.instructor._id === user._id) {
      toast.error('You cannot enroll in your own course.');
      return;
    }

    if (isEnrolled) {
      toast.info('You are already enrolled in this course!');
      return;
    }

    // If the course is free, enroll directly
    if (course.price === 0) {
      setEnrolling(true);
      try {
        await courseAPI.enrollInCourse(id, user._id);
        
        // Update local state
        setIsEnrolled(true);
        setCourse(prev => ({
          ...prev,
          enrolledStudents: prev.enrolledStudents + 1
        }));
        
        toast.success('Successfully enrolled in the course!');
        
        // Redirect to course content or show enrollment confirmation
        setTimeout(() => {
          navigate(`/course/${id}/learn`);
        }, 1500);
        
      } catch (error) {
        console.error('Error enrolling in course:', error);
        toast.error(error.response?.data?.message || 'Failed to enroll in course');
      } finally {
        setEnrolling(false);
      }
    } else {
      // If the course has a price, redirect to payment page
      setEnrolling(true);
      setTimeout(() => {
        navigate(`/payment/${id}`, { state: { courseId: id } });
        setEnrolling(false);
      }, 500);
    }
  };

  useEffect(() => {
    fetchCourse();
  }, [fetchCourse]);

  // Check enrollment when auth loading completes
  useEffect(() => {
    if (!authLoading && isAuthenticated && user && user._id && course) {
      checkEnrollmentStatus();
    }
  }, [authLoading, isAuthenticated, user, course, checkEnrollmentStatus]);

  // Fetch course ratings
  useEffect(() => {
    if (course) {
      fetchCourseRatings();
    }
  }, [course, fetchCourseRatings]);

  const handleRatingSubmit = async () => {
    if (!userRating) {
      toast.error('Please select a rating');
      return;
    }

    if (!isEnrolled) {
      toast.error('You must be enrolled to rate this course');
      return;
    }

    if (user && user.role === 'instructor') {
      toast.error('Instructors cannot rate courses');
      return;
    }

    setSubmittingRating(true);
    try {
      await courseAPI.rateCourse(id, {
        userId: user._id,
        rating: userRating,
        review: userReview
      });
      
      toast.success('Rating submitted successfully!');
      setShowRatingForm(false);
      
      // Refresh course data and ratings
      fetchCourse();
      fetchCourseRatings();
    } catch (error) {
      console.error('Error submitting rating:', error);
      toast.error(error.response?.data?.message || 'Failed to submit rating');
    } finally {
      setSubmittingRating(false);
    }
  };



  const getVideoEmbedUrl = (videoUrl) => {
    // Handle YouTube URLs
    if (videoUrl.includes('youtube.com/watch?v=')) {
      const videoId = videoUrl.split('v=')[1];
      return `https://www.youtube.com/embed/${videoId}`;
    }
    // Handle YouTube short URLs
    if (videoUrl.includes('youtu.be/')) {
      const videoId = videoUrl.split('youtu.be/')[1];
      return `https://www.youtube.com/embed/${videoId}`;
    }
    // Return original URL if not YouTube
    return videoUrl;
  };

  if (loading || authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (error || !course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">😕</div>
          <h2 className="text-2xl font-bold text-secondary-900 mb-2">
            {error || 'Course not found'}
          </h2>
          <p className="text-secondary-600 mb-4">
            The course you're looking for doesn't exist or has been removed.
          </p>
          <Link
            to="/courses"
            className="btn-primary inline-flex items-center space-x-2"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Courses</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-secondary-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <div className="mb-6">
          <Link
            to="/courses"
            className="inline-flex items-center space-x-2 text-primary-600 hover:text-primary-700 transition-colors duration-200"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Courses</span>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Video Player */}
            <div className="bg-black rounded-xl overflow-hidden mb-8">
              <div className="aspect-video">
                {(() => {
                  // Check if user can access the video
                  const canAccessVideo = isEnrolled || 
                    (user && user.role === 'instructor' && course.instructor && course.instructor._id === user._id);
                  
                  if (canAccessVideo) {
                    return (
                      <iframe
                        src={getVideoEmbedUrl(course.videoUrl)}
                        title={course.title}
                        className="w-full h-full"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      ></iframe>
                    );
                  } else {
                    return (
                      <div className="w-full h-full flex items-center justify-center bg-gray-900">
                        <div className="text-center text-white">
                          <div className="text-6xl mb-4">🔒</div>
                          <h3 className="text-xl font-semibold mb-2">Course Content Locked</h3>
                          <p className="text-gray-300 mb-4">
                            {user && user.role === 'instructor' 
                              ? 'You can only access courses you created'
                              : 'Enroll in this course to access the full video content'
                            }
                          </p>
                          <button 
                            onClick={() => setShowVideoModal(true)}
                            className="bg-primary-600 text-white px-4 py-2 rounded-lg inline-block hover:bg-primary-700 transition-colors duration-200"
                          >
                            <div className="flex items-center space-x-2">
                              <Play className="h-5 w-5" />
                              <span>Watch Demo</span>
                            </div>
                          </button>
                          
                          {/* Video Modal */}
                          <VideoModal 
                            isOpen={showVideoModal} 
                            onClose={() => setShowVideoModal(false)} 
                            videoUrl={course.videoUrl} 
                          />
                        </div>
                      </div>
                    );
                  }
                })()}
              </div>
            </div>

            {/* Course Title and Basic Info */}
            <div className="bg-white rounded-xl p-6 mb-6">
              <h1 className="text-3xl font-bold text-secondary-900 mb-4">
                {course.title}
              </h1>
              
              <div className="flex flex-wrap items-center gap-4 mb-4">
                <Rating 
                  rating={course.rating} 
                  readonly={true} 
                  size="md"
                />
                
                <div className="flex items-center space-x-1 text-secondary-600">
                  <Users className="h-4 w-4" />
                  <span className="text-sm">{course.enrolledStudents} students enrolled</span>
                </div>
                
                <div className="flex items-center space-x-1 text-secondary-600">
                  <Clock className="h-4 w-4" />
                  <span className="text-sm">{course.duration}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <span className="bg-primary-100 text-primary-800 px-3 py-1 rounded-full text-sm font-medium">
                  {course.category}
                </span>
                <span className="bg-secondary-100 text-secondary-800 px-3 py-1 rounded-full text-sm font-medium">
                  {course.level}
                </span>
                {course.tags && course.tags.map((tag, index) => (
                  <span key={index} className="bg-secondary-100 text-secondary-800 px-3 py-1 rounded-full text-sm font-medium flex items-center space-x-1">
                    <Tag className="h-3 w-3" />
                    <span>{tag}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Course Description */}
            <div className="bg-white rounded-xl p-6 mb-6">
              <h2 className="text-xl font-semibold text-secondary-900 mb-4">
                About this course
              </h2>
              <div className="prose max-w-none text-secondary-700">
                {(() => {
                  // Check if user can access full description
                  const canAccessFullDescription = isEnrolled || 
                    (user && user.role === 'instructor' && course.instructor && course.instructor._id === user._id);
                  
                  if (canAccessFullDescription) {
                    return <p className="whitespace-pre-wrap">{course.description}</p>;
                  } else {
                    return (
                      <div>
                        <p className="whitespace-pre-wrap">
                          {course.description.length > 200 
                            ? course.description.substring(0, 200) + '...' 
                            : course.description
                          }
                        </p>
                        <div className="mt-4 p-4 bg-secondary-50 rounded-lg border border-secondary-200">
                          <div className="flex items-center space-x-2 mb-2">
                            <div className="w-2 h-2 bg-primary-600 rounded-full"></div>
                            <span className="font-medium text-secondary-900">Preview Mode</span>
                          </div>
                          <p className="text-sm text-secondary-600">
                            {user && user.role === 'instructor' 
                              ? 'You can only access the full content of courses you created'
                              : 'This is a preview of the course content. Enroll to access the full description, complete video lessons, and all course materials.'
                            }
                          </p>
                        </div>
                      </div>
                    );
                  }
                })()}
              </div>
            </div>

            {/* Instructor Info */}
            {course.instructor && (
              <div className="bg-white rounded-xl p-6 mb-6">
                <h2 className="text-xl font-semibold text-secondary-900 mb-4">
                  About the instructor
                </h2>
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center">
                    <span className="text-xl font-semibold text-primary-600">
                      {course.instructor.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-secondary-900">
                      {course.instructor.name}
                    </h3>
                    <p className="text-secondary-600">{course.instructor.email}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Ratings Section */}
            <div className="bg-white rounded-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-secondary-900">
                  Student Reviews
                </h2>
                {isEnrolled && user && user.role === 'student' && (
                  <button
                    onClick={() => setShowRatingForm(!showRatingForm)}
                    className="btn-secondary flex items-center space-x-2"
                  >
                    <MessageSquare className="h-4 w-4" />
                    <span>{userRating ? 'Update Review' : 'Write Review'}</span>
                  </button>
                )}
              </div>

              {/* Rating Form */}
              {showRatingForm && isEnrolled && user && user.role === 'student' && (
                <div className="bg-secondary-50 rounded-lg p-4 mb-6">
                  <h3 className="font-semibold text-secondary-900 mb-3">
                    Rate this course
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-secondary-700 mb-2">
                        Your Rating
                      </label>
                      <Rating
                        rating={userRating}
                        onRatingChange={setUserRating}
                        readonly={false}
                        size="lg"
                        showValue={false}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-secondary-700 mb-2">
                        Your Review (Optional)
                      </label>
                      <textarea
                        value={userReview}
                        onChange={(e) => setUserReview(e.target.value)}
                        rows="3"
                        className="input-field"
                        placeholder="Share your experience with this course..."
                        maxLength="500"
                      />
                      <p className="text-xs text-secondary-500 mt-1">
                        {userReview.length}/500 characters
                      </p>
                    </div>
                    <div className="flex space-x-3">
                      <button
                        onClick={handleRatingSubmit}
                        disabled={submittingRating || !userRating}
                        className="btn-primary"
                      >
                        {submittingRating ? 'Submitting...' : 'Submit Rating'}
                      </button>
                      <button
                        onClick={() => setShowRatingForm(false)}
                        className="btn-secondary"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Ratings List */}
              <div className="space-y-4">
                {courseRatings.length === 0 ? (
                  <p className="text-secondary-600 text-center py-8">
                    No reviews yet. Be the first to review this course!
                  </p>
                ) : (
                  courseRatings.map((rating, index) => (
                    <div key={index} className="border-b border-secondary-200 pb-4 last:border-b-0">
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
                            <span className="text-sm font-semibold text-primary-600">
                              {rating.user.name.charAt(0).toUpperCase()}
                            </span>
                          </div>
                          <div>
                            <p className="font-medium text-secondary-900">
                              {rating.user.name}
                            </p>
                            <Rating
                              rating={rating.rating}
                              readonly={true}
                              size="sm"
                              showValue={false}
                            />
                          </div>
                        </div>
                        <span className="text-xs text-secondary-500">
                          {new Date(rating.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      {rating.review && (
                        <p className="text-secondary-700 text-sm ml-11">
                          {rating.review}
                        </p>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl p-6 shadow-lg sticky top-24">
              <div className="text-center mb-6">
                <div className="text-3xl font-bold text-primary-600 mb-2">
                  {course.price === 0 ? 'Free' : `₹${course.price}`}
                </div>
                {isEnrolled ? (
                  <Link
                    to={`/course/${id}/learn`}
                    className="w-full btn-primary flex items-center justify-center space-x-2"
                  >
                    <Play className="h-5 w-5" />
                    <span>Continue Learning</span>
                  </Link>
                ) : (
                  <button 
                    onClick={handleEnroll}
                    disabled={enrolling}
                    className="w-full btn-primary flex items-center justify-center space-x-2"
                  >
                    {enrolling ? (
                      <>
                        <div className="animate-spin h-5 w-5 border-b-2 border-white"></div>
                        <span>Enrolling...</span>
                      </>
                    ) : (
                      <>
                        <Play className="h-5 w-5" />
                        <span>Enroll Now</span>
                      </>
                    )}
                  </button>
                )}
              </div>

              <div className="space-y-4">
                {isEnrolled && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm font-medium text-green-800">You're enrolled!</span>
                    </div>
                    <p className="text-xs text-green-700 mt-1">
                      Access all course content and track your progress
                    </p>
                  </div>
                )}
                
                <div className="flex items-center justify-between py-2 border-b border-secondary-200">
                  <span className="text-secondary-600">Duration</span>
                  <span className="font-medium">{course.duration}</span>
                </div>
                
                <div className="flex items-center justify-between py-2 border-b border-secondary-200">
                  <span className="text-secondary-600">Level</span>
                  <span className="font-medium">{course.level}</span>
                </div>
                
                <div className="flex items-center justify-between py-2 border-b border-secondary-200">
                  <span className="text-secondary-600">Category</span>
                  <span className="font-medium">{course.category}</span>
                </div>
                
                <div className="flex items-center justify-between py-2 border-b border-secondary-200">
                  <span className="text-secondary-600">Students</span>
                  <span className="font-medium">{course.enrolledStudents}</span>
                </div>
                
                <div className="flex items-center justify-between py-2">
                  <span className="text-secondary-600">Rating</span>
                  <Rating
                    rating={course.rating}
                    readonly={true}
                    size="sm"
                    showValue={false}
                  />
                </div>
              </div>

              <div className="mt-6 pt-6 border-t border-secondary-200">
                <h3 className="font-semibold text-secondary-900 mb-3">
                  What you'll learn
                </h3>
                <ul className="space-y-2 text-sm text-secondary-700">
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-primary-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Comprehensive understanding of the subject</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-primary-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Practical skills and real-world applications</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <div className="w-1.5 h-1.5 bg-primary-600 rounded-full mt-2 flex-shrink-0"></div>
                    <span>Certificate upon completion</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;
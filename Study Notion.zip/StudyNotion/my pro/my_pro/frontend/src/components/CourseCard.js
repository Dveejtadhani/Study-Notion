import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Clock, Users, Play } from 'lucide-react';
import Rating from './Rating';
import VideoModal from './VideoModal';

const CourseCard = ({ course, showViewButton = true }) => {
  const [showVideoModal, setShowVideoModal] = useState(false);


  return (
    <div className="card card-hover">
      <div className="relative">
        <img
          src={course.thumbnail}
          alt={course.title}
          className="w-full h-48 object-cover"
          onError={(e) => {
            e.target.src = 'https://via.placeholder.com/400x300?text=Course+Image';
          }}
        />
        <div className="absolute top-2 right-2">
          <span className="bg-primary-600 text-white px-2 py-1 rounded-full text-xs font-medium">
            {course.category}
          </span>
        </div>
        <div 
          className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center cursor-pointer"
          onClick={(e) => {
            e.preventDefault();
            setShowVideoModal(true);
          }}
        >
          <Play className="h-12 w-12 text-white opacity-0 hover:opacity-100 transition-opacity duration-300" />
        </div>
        
        {/* Video Modal */}
        <VideoModal 
          isOpen={showVideoModal} 
          onClose={() => setShowVideoModal(false)} 
          videoUrl={course.videoUrl} 
        />
      </div>
      
      <div className="p-6">
        <h3 className="text-lg font-semibold text-secondary-900 mb-2 line-clamp-2">
          {course.title}
        </h3>
        
        <p className="text-secondary-600 text-sm mb-4 line-clamp-2">
          {course.description}
        </p>
        
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4 text-sm text-secondary-500">
            <div className="flex items-center space-x-1">
              <Clock className="h-4 w-4" />
              <span>{course.duration}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Users className="h-4 w-4" />
              <span>{course.enrolledStudents} students</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between mb-4">
          <Rating 
            rating={course.rating} 
            readonly={true} 
            size="sm" 
            showValue={false}
          />
          <span className="text-sm font-medium text-secondary-600">
            {course.level}
          </span>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="text-lg font-bold text-primary-600">
            {course.price === 0 ? 'Free' : `₹${course.price}`}
          </div>
          {showViewButton && (
            <Link
              to={`/courses/${course._id}`}
              className="btn-primary text-sm"
            >
              View Course
            </Link>
          )}
        </div>
        
        {course.instructor && (
          <div className="mt-4 pt-4 border-t border-secondary-200">
            <p className="text-sm text-secondary-600">
              By <span className="font-medium">{course.instructor.name}</span>
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CourseCard;
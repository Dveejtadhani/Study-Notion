const Course = require('../models/Course');
const User = require('../models/User');
const { validationResult } = require('express-validator');

// @desc    Get all courses
// @route   GET /api/courses
// @access  Public
const getAllCourses = async (req, res) => {
  try {
    const { category, search, page = 1, limit = 10 } = req.query;
    
    console.log('Search request:', { category, search, page, limit });
    
    let query = {};
    
    // Filter by category
    if (category && category !== 'All') {
      query.category = category;
    }
    
    // Search functionality
    if (search) {
      const searchRegex = new RegExp(search, 'i'); // Case-insensitive search
      query.$or = [
        { title: searchRegex },
        { description: searchRegex },
        { tags: searchRegex },
        { category: searchRegex }
      ];
      console.log('Search query:', JSON.stringify(query, null, 2));
    }
    
    const skip = (page - 1) * limit;
    
    const courses = await Course.find(query)
      .populate('instructor', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));
    
    const total = await Course.countDocuments(query);
    
    res.json({
      success: true,
      courses,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / limit),
        totalCourses: total,
        hasNext: skip + courses.length < total,
        hasPrev: page > 1
      }
    });
    
  } catch (error) {
    console.error('Get courses error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching courses'
    });
  }
};

// @desc    Get single course
// @route   GET /api/courses/:id
// @access  Public
const getCourse = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id)
      .populate('instructor', 'name email');
    
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }
    
    res.json({
      success: true,
      course
    });
    
  } catch (error) {
    console.error('Get course error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching course'
    });
  }
};

// @desc    Create course
// @route   POST /api/courses
// @access  Private (instructor)
const createCourse = async (req, res) => {
  try {
    console.log('Create course request body:', req.body);
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('Validation errors:', errors.array());
      return res.status(400).json({ 
        success: false, 
        message: 'Validation error',
        errors: errors.array() 
      });
    }

    const { title, description, category, thumbnail, videoUrl, price, duration, level, tags, instructorId } = req.body;
    
    // Check if user is an instructor
    const instructor = await User.findById(instructorId);
    if (!instructor) {
      return res.status(404).json({
        success: false,
        message: 'Instructor not found'
      });
    }
    
    if (instructor.role !== 'instructor') {
      return res.status(403).json({
        success: false,
        message: 'Only instructors can create courses'
      });
    }
    
    console.log('Creating course with data:', {
      title,
      description,
      category,
      thumbnail,
      videoUrl,
      price,
      duration,
      level,
      tags,
      instructorId
    });
    
    // Create course
    const course = new Course({
      title,
      description,
      category,
      thumbnail,
      videoUrl,
      price: price || 0,
      duration: duration || '0 hours',
      level: level || 'Beginner',
      tags: tags || [],
      instructor: instructorId
    });
    
    console.log('Course object before save:', course);
    
    await course.save();
    
    const populatedCourse = await Course.findById(course._id)
      .populate('instructor', 'name email');
    
    console.log('Course created successfully:', populatedCourse);
    
    res.status(201).json({
      success: true,
      message: 'Course created successfully',
      course: populatedCourse
    });
    
  } catch (error) {
    console.error('Create course error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while creating course',
      error: error.message
    });
  }
};

// @desc    Update course
// @route   PUT /api/courses/:id
// @access  Private (instructor)
const updateCourse = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ 
        success: false, 
        message: 'Validation error',
        errors: errors.array() 
      });
    }

    const course = await Course.findById(req.params.id);
    
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }
    
    // Check if user is the instructor
    if (course.instructor.toString() !== req.body.instructorId) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to update this course'
      });
    }
    
    const updatedCourse = await Course.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    ).populate('instructor', 'name email');
    
    res.json({
      success: true,
      message: 'Course updated successfully',
      course: updatedCourse
    });
    
  } catch (error) {
    console.error('Update course error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while updating course'
    });
  }
};

// @desc    Delete course
// @route   DELETE /api/courses/:id
// @access  Private (instructor)
const deleteCourse = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }
    
    // Check if user is the instructor
    if (course.instructor.toString() !== req.body.instructorId) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to delete this course'
      });
    }
    
    await Course.findByIdAndDelete(req.params.id);
    
    res.json({
      success: true,
      message: 'Course deleted successfully'
    });
    
  } catch (error) {
    console.error('Delete course error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while deleting course'
    });
  }
};

// @desc    Get courses by instructor
// @route   GET /api/courses/instructor/:instructorId
// @access  Public
const getCoursesByInstructor = async (req, res) => {
  try {
    const courses = await Course.find({ instructor: req.params.instructorId })
      .populate('instructor', 'name email')
      .sort({ createdAt: -1 });
    
    res.json({
      success: true,
      courses
    });
    
  } catch (error) {
    console.error('Get instructor courses error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching instructor courses'
    });
  }
};

// @desc    Enroll in course
// @route   POST /api/courses/:id/enroll
// @access  Private
const enrollInCourse = async (req, res) => {
  try {
    const { userId } = req.body;
    const courseId = req.params.id;

    // Check if course exists
    const course = await Course.findById(courseId);
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }

    // Check if user exists
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    // Check if user is a student
    if (user.role !== 'student') {
      return res.status(403).json({
        success: false,
        message: 'Only students can enroll in courses'
      });
    }
    
    // Check if user is trying to enroll in their own course
    if (course.instructor.toString() === userId) {
      return res.status(403).json({
        success: false,
        message: 'You cannot enroll in your own course'
      });
    }

    // Check if already enrolled
    if (user.enrolledCourses && user.enrolledCourses.includes(courseId)) {
      return res.status(400).json({
        success: false,
        message: 'Already enrolled in this course'
      });
    }

    // Add course to user's enrolled courses
    if (!user.enrolledCourses) {
      user.enrolledCourses = [];
    }
    user.enrolledCourses.push(courseId);
    await user.save();

    // Increment course enrollment count
    course.enrolledStudents += 1;
    await course.save();

    res.json({
      success: true,
      message: 'Successfully enrolled in course',
      course: {
        id: course._id,
        title: course.title,
        enrolledStudents: course.enrolledStudents
      }
    });

  } catch (error) {
    console.error('Enroll in course error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while enrolling in course'
    });
  }
};

// @desc    Check enrollment status
// @route   GET /api/courses/:id/enrollment/:userId
// @access  Private
const checkEnrollment = async (req, res) => {
  try {
    const { userId } = req.params;
    const courseId = req.params.id;

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    const isEnrolled = user.enrolledCourses && user.enrolledCourses.includes(courseId);

    res.json({
      success: true,
      isEnrolled
    });

  } catch (error) {
    console.error('Check enrollment error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while checking enrollment'
    });
  }
};

// @desc    Get enrolled courses for user
// @route   GET /api/courses/user/:userId/enrolled-courses
// @access  Private
const getEnrolledCourses = async (req, res) => {
  try {
    const { userId } = req.params;

    const user = await User.findById(userId).populate('enrolledCourses');
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    const enrolledCourses = await Course.find({
      _id: { $in: user.enrolledCourses || [] }
    }).populate('instructor', 'name email');

    res.json({
      success: true,
      courses: enrolledCourses
    });

  } catch (error) {
    console.error('Get enrolled courses error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching enrolled courses'
    });
  }
};

// @desc    Rate a course
// @route   POST /api/courses/:id/rate
// @access  Private (enrolled students)
const rateCourse = async (req, res) => {
  try {
    const courseId = req.params.id;
    const { userId, rating, review } = req.body;
    
    console.log('Rating course request - full details:', { 
      courseId, 
      userId, 
      rating, 
      review,
      params: req.params,
      body: req.body,
      url: req.url
    });
    
    // Check if course exists
    const course = await Course.findById(courseId);
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }
    
    // Check if user is enrolled
    const user = await User.findById(userId);
    if (!user || !user.enrolledCourses.includes(courseId)) {
      return res.status(403).json({
        success: false,
        message: 'You must be enrolled in this course to rate it'
      });
    }
    
    // Check if user is a student
    if (user.role !== 'student') {
      return res.status(403).json({
        success: false,
        message: 'Only students can rate courses'
      });
    }
    
    // Check if user has already rated this course
    const existingRatingIndex = course.ratings.findIndex(
      r => r.user.toString() === userId
    );
    
    if (existingRatingIndex !== -1) {
      // Update existing rating
      course.ratings[existingRatingIndex].rating = rating;
      course.ratings[existingRatingIndex].review = review || '';
      course.ratings[existingRatingIndex].createdAt = new Date();
    } else {
      // Add new rating
      course.ratings.push({
        user: userId,
        rating,
        review: review || '',
        createdAt: new Date()
      });
    }
    
    // Calculate new average rating
    const totalRating = course.ratings.reduce((sum, r) => sum + r.rating, 0);
    course.rating = totalRating / course.ratings.length;
    
    await course.save();
    
    const populatedCourse = await Course.findById(courseId)
      .populate('instructor', 'name email')
      .populate('ratings.user', 'name email');
    
    console.log('Course rated successfully:', {
      courseId,
      newRating: course.rating,
      totalRatings: course.ratings.length
    });
    
    res.json({
      success: true,
      message: 'Course rated successfully',
      course: populatedCourse
    });
    
  } catch (error) {
    console.error('Rate course error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while rating course',
      error: error.message
    });
  }
};

// @desc    Get course ratings
// @route   GET /api/courses/:id/ratings
// @access  Public
const getCourseRatings = async (req, res) => {
  try {
    const courseId = req.params.id;
    
    const course = await Course.findById(courseId)
      .populate('ratings.user', 'name email')
      .select('ratings rating');
    
    if (!course) {
      return res.status(404).json({
        success: false,
        message: 'Course not found'
      });
    }
    
    res.json({
      success: true,
      ratings: course.ratings,
      averageRating: course.rating,
      totalRatings: course.ratings.length
    });
    
  } catch (error) {
    console.error('Get course ratings error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching ratings'
    });
  }
};

module.exports = {
  getAllCourses,
  getCourse,
  createCourse,
  updateCourse,
  deleteCourse,
  getCoursesByInstructor,
  enrollInCourse,
  checkEnrollment,
  getEnrolledCourses,
  rateCourse,
  getCourseRatings
}; 
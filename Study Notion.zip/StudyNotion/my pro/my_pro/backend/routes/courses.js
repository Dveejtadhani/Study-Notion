const express = require('express');
const { body } = require('express-validator');
const {
  getAllCourses,
  getCourse,
  createCourse,
  updateCourse,
  deleteCourse,
  getCoursesByInstructor,
  enrollInCourse,
  checkEnrollment,
  getEnrolledCourses,
  rateCourse,
  getCourseRatings
} = require('../controllers/courseController');

const router = express.Router();

// Validation middleware
const courseValidation = [
  body('title')
    .trim()
    .isLength({ min: 3 })
    .withMessage('Title must be at least 3 characters long'),
  body('description')
    .trim()
    .isLength({ min: 10 })
    .withMessage('Description must be at least 10 characters long'),
  body('category')
    .isIn(['Programming', 'Design', 'Business', 'Marketing', 'Music', 'Photography', 'Data Science', 'Backend Development', 'Frontend Development', 'Mobile Development', 'DevOps', 'Other'])
    .withMessage('Please select a valid category'),
  body('thumbnail')
    .notEmpty()
    .withMessage('Thumbnail URL is required'),
  body('videoUrl')
    .notEmpty()
    .withMessage('Video URL is required'),
  body('price')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Price must be a positive number'),
  body('level')
    .optional()
    .isIn(['Beginner', 'Intermediate', 'Advanced'])
    .withMessage('Please select a valid level')
];

// Routes
router.get('/', getAllCourses);
router.get('/instructor/:instructorId', getCoursesByInstructor);
router.get('/user/:userId/enrolled-courses', getEnrolledCourses);

// Course CRUD routes
router.get('/:id', getCourse);
router.post('/', courseValidation, createCourse);
router.put('/:id', courseValidation, updateCourse);
router.delete('/:id', deleteCourse);

// Enrollment routes
router.post('/:id/enroll', enrollInCourse);
router.get('/:id/enrollment/:userId', checkEnrollment);

// Rating validation
const ratingValidation = [
  body('rating')
    .isInt({ min: 1, max: 5 })
    .withMessage('Rating must be between 1 and 5'),
  body('review')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Review must be less than 500 characters'),
  body('userId')
    .notEmpty()
    .withMessage('User ID is required')
];

// Rating routes
router.post('/:id/rate', ratingValidation, rateCourse);
router.get('/:id/ratings', getCourseRatings);

module.exports = router; 